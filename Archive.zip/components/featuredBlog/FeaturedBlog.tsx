const FeaturedBlog = () => {
    return (
        <div>

        </div>
    );
};

export default FeaturedBlog;