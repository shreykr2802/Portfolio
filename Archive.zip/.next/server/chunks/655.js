exports.id = 655;
exports.ids = [655];
exports.modules = {

/***/ 8361:
/***/ ((module) => {

// Exports
module.exports = {
	"action-button-container": "ActionButtonContainer_action-button-container__uO3Xn"
};


/***/ }),

/***/ 5190:
/***/ ((module) => {

// Exports
module.exports = {
	"input-label-section": "LabelAndInput_input-label-section__h2AB0",
	"section-input-label": "LabelAndInput_section-input-label__Rqf6M",
	"section-input-value": "LabelAndInput_section-input-value__l9XW8",
	"section-input-textarea-value": "LabelAndInput_section-input-textarea-value__3IQSd"
};


/***/ }),

/***/ 2792:
/***/ ((module) => {

// Exports
module.exports = {
	"label-input-container": "LabelAndInputContainer_label-input-container__J31p2"
};


/***/ }),

/***/ 7817:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _ActionButtonContainer_module_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8361);
/* harmony import */ var _ActionButtonContainer_module_scss__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_ActionButtonContainer_module_scss__WEBPACK_IMPORTED_MODULE_1__);


const ActionButtonContainer = (props)=>{
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: (_ActionButtonContainer_module_scss__WEBPACK_IMPORTED_MODULE_1___default()["action-button-container"]),
        children: props.children
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ActionButtonContainer);


/***/ }),

/***/ 7017:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _LabelAndInput_module_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5190);
/* harmony import */ var _LabelAndInput_module_scss__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_LabelAndInput_module_scss__WEBPACK_IMPORTED_MODULE_1__);


const LabelAndInput = ({ name , type , value , setValue  })=>{
    const renderInput = ()=>{
        if (type === "file") {
            return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                type: type,
                onChange: (e)=>setValue(e.target.files)
                ,
                className: (_LabelAndInput_module_scss__WEBPACK_IMPORTED_MODULE_1___default()["section-input-value"])
            }));
        } else if (type === "text") {
            return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                type: type,
                value: value,
                onChange: (e)=>setValue(e.target.value)
                ,
                className: (_LabelAndInput_module_scss__WEBPACK_IMPORTED_MODULE_1___default()["section-input-value"])
            }));
        } else if (type === "textarea") {
            return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("textarea", {
                value: value,
                onChange: (e)=>setValue(e.target.value)
                ,
                className: (_LabelAndInput_module_scss__WEBPACK_IMPORTED_MODULE_1___default()["section-input-textarea-value"])
            }));
        }
    };
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_LabelAndInput_module_scss__WEBPACK_IMPORTED_MODULE_1___default()["input-label-section"]),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                className: (_LabelAndInput_module_scss__WEBPACK_IMPORTED_MODULE_1___default()["section-input-label"]),
                children: name
            }),
            renderInput()
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (LabelAndInput);


/***/ }),

/***/ 701:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _LabelAndInputContainer_module_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2792);
/* harmony import */ var _LabelAndInputContainer_module_scss__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_LabelAndInputContainer_module_scss__WEBPACK_IMPORTED_MODULE_1__);


const LabelAndInputContainer = (props)=>{
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: (_LabelAndInputContainer_module_scss__WEBPACK_IMPORTED_MODULE_1___default()["label-input-container"]),
        children: props.children
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (LabelAndInputContainer);


/***/ }),

/***/ 5803:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);


const withAuth = (WrappedComponent)=>{
    return (props)=>{
        if (false) {}
        return null;
    };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (withAuth);


/***/ })

};
;