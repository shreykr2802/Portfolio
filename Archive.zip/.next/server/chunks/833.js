"use strict";
exports.id = 833;
exports.ids = [833];
exports.modules = {

/***/ 9833:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "a": () => (/* binding */ fetchBlogDataStart),
/* harmony export */   "Tz": () => (/* binding */ fetchBlogDataSuccess),
/* harmony export */   "b8": () => (/* binding */ fetchBlogDataFailed),
/* harmony export */   "I2": () => (/* binding */ fetchBlogDataByIdStart),
/* harmony export */   "MO": () => (/* binding */ fetchBlogDataByIdSuccess),
/* harmony export */   "Mi": () => (/* binding */ fetchBlogDataByIdFailed),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const initialState = {
    blogs: [],
    error: "",
    loading: false,
    blogData: {}
};
const blogSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "blogData",
    initialState,
    reducers: {
        fetchBlogDataStart: (state)=>{
            state.error = "";
            state.loading = true;
        },
        fetchBlogDataSuccess: (state, action)=>{
            state.error = "";
            state.loading = false;
            state.blogs = action.payload;
        },
        fetchBlogDataFailed: (state, action)=>{
            state.error = action.payload;
            state.loading = false;
        },
        fetchBlogDataByIdStart: (state, action)=>{
            state.error = "";
            state.loading = true;
        },
        fetchBlogDataByIdSuccess: (state, action)=>{
            state.error = "";
            state.loading = false;
            state.blogData = action.payload;
        },
        fetchBlogDataByIdFailed: (state, action)=>{
            state.error = action.payload;
            state.loading = false;
        }
    }
});
const { fetchBlogDataStart , fetchBlogDataSuccess , fetchBlogDataFailed , fetchBlogDataByIdStart , fetchBlogDataByIdSuccess , fetchBlogDataByIdFailed  } = blogSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (blogSlice.reducer);


/***/ })

};
;