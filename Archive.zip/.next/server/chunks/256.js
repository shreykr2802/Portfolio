"use strict";
exports.id = 256;
exports.ids = [256];
exports.modules = {

/***/ 3256:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "zd": () => (/* binding */ fetchTagDataStart),
/* harmony export */   "bM": () => (/* binding */ fetchTagDataSuccess),
/* harmony export */   "b1": () => (/* binding */ fetchTagDataFailed),
/* harmony export */   "Ls": () => (/* binding */ fetchPlainTagDataStart),
/* harmony export */   "yq": () => (/* binding */ fetchPlainTagDataSuccess),
/* harmony export */   "rW": () => (/* binding */ fetchPlainTagDataFailed),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const initialState = {
    tags: [],
    error: "",
    loading: false,
    plainTags: []
};
const tagSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "tagData",
    initialState,
    reducers: {
        fetchTagDataStart: (state)=>{
            state.error = "";
            state.loading = true;
        },
        fetchTagDataSuccess: (state, action)=>{
            state.error = "";
            state.loading = false;
            state.tags = action.payload;
        },
        fetchTagDataFailed: (state, action)=>{
            state.error = action.payload;
            state.loading = false;
        },
        fetchPlainTagDataStart: (state)=>{
            state.error = "";
            state.loading = true;
        },
        fetchPlainTagDataSuccess: (state, action)=>{
            state.error = "";
            state.loading = false;
            state.plainTags = action.payload;
        },
        fetchPlainTagDataFailed: (state, action)=>{
            state.error = action.payload;
            state.loading = false;
        }
    }
});
const { fetchTagDataStart , fetchTagDataSuccess , fetchTagDataFailed , fetchPlainTagDataStart , fetchPlainTagDataSuccess , fetchPlainTagDataFailed  } = tagSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (tagSlice.reducer);


/***/ })

};
;