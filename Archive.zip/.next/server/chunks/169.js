exports.id = 169;
exports.ids = [169];
exports.modules = {

/***/ 8302:
/***/ ((module) => {

// Exports
module.exports = {
	"footer-social-media": "SocialMediaFooter_footer-social-media__6aOE7",
	"text-social-media": "SocialMediaFooter_text-social-media__Zrj7d",
	"social-media-links": "SocialMediaFooter_social-media-links__mVSCh",
	"text-copyright": "SocialMediaFooter_text-copyright__lpdDb"
};


/***/ }),

/***/ 3110:
/***/ ((module) => {

// Exports
module.exports = {
	"main-section": "Home_main-section__XjBJt",
	"main-text-intro": "Home_main-text-intro__4ldTh",
	"margin-top-6": "Home_margin-top-6__CKcJr"
};


/***/ }),

/***/ 5727:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _iconify_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5566);
/* harmony import */ var _SocialMediaFooter_module_scss__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8302);
/* harmony import */ var _SocialMediaFooter_module_scss__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_SocialMediaFooter_module_scss__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_iconify_react__WEBPACK_IMPORTED_MODULE_2__]);
_iconify_react__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];




const SocialMediaLink = ({ iconName , height , width , link  })=>{
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
        href: link,
        target: "_blank",
        rel: "noopener noreferrer",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_iconify_react__WEBPACK_IMPORTED_MODULE_2__.Icon, {
            icon: iconName,
            width: width,
            height: height,
            color: "white"
        })
    }));
};
const SocialMediaFooter = ()=>{
    const socialMedias = [
        {
            name: "instagram",
            iconName: "bi:instagram",
            height: "48",
            width: "48",
            link: "https://instagram.com/shreykr2802"
        },
        {
            name: "linkedin",
            iconName: "bi:linkedin",
            height: "48",
            width: "48",
            link: "https://linkedin.com/in/shreykr2802"
        },
        {
            name: "github",
            iconName: "bi:github",
            height: "48",
            width: "48",
            link: "https://github.com/shreykr2802"
        },
        {
            name: "twitter",
            iconName: "bi:twitter",
            height: "48",
            width: "48",
            link: "https://twitter.com/shreykr2802"
        },
        {
            name: "mail",
            iconName: "bi:envelope",
            height: "48",
            width: "48",
            link: "mailto:shreykr2802@gmail.com"
        }
    ];
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("footer", {
                className: (_SocialMediaFooter_module_scss__WEBPACK_IMPORTED_MODULE_3___default()["footer-social-media"]),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        className: (_SocialMediaFooter_module_scss__WEBPACK_IMPORTED_MODULE_3___default()["text-social-media"]),
                        children: "I am Available on Social Media"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: (_SocialMediaFooter_module_scss__WEBPACK_IMPORTED_MODULE_3___default()["social-media-links"]),
                        children: socialMedias.map((socialMedia)=>{
                            return(/*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createElement)(SocialMediaLink, {
                                ...socialMedia,
                                key: socialMedia.name
                            }));
                        })
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                    className: (_SocialMediaFooter_module_scss__WEBPACK_IMPORTED_MODULE_3___default()["text-copyright"]),
                    children: [
                        "Created with ",
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_iconify_react__WEBPACK_IMPORTED_MODULE_2__.Icon, {
                            icon: "ant-design:heart-filled",
                            height: "12",
                            width: "12",
                            color: "#DC4040"
                        }),
                        ". All Designs and rights reserved. Shrey Kumar",
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("sup", {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_iconify_react__WEBPACK_IMPORTED_MODULE_2__.Icon, {
                                icon: "ant-design:copyright-circle-outlined",
                                height: "12",
                                width: "12",
                                color: "#DC4040"
                            })
                        })
                    ]
                })
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SocialMediaFooter);

});

/***/ })

};
;