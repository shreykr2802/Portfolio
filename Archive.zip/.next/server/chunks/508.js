exports.id = 508;
exports.ids = [508];
exports.modules = {

/***/ 3481:
/***/ ((module) => {

// Exports
module.exports = {
	"input-label-section": "MultiSelectLabelInput_input-label-section__jtmtl",
	"section-input-label": "MultiSelectLabelInput_section-input-label__bMeEx",
	"section-input-value": "MultiSelectLabelInput_section-input-value__2u_cu"
};


/***/ }),

/***/ 3508:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _MultiSelectLabelInput_module_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3481);
/* harmony import */ var _MultiSelectLabelInput_module_scss__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_MultiSelectLabelInput_module_scss__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var multiselect_react_dropdown__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9261);
/* harmony import */ var multiselect_react_dropdown__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(multiselect_react_dropdown__WEBPACK_IMPORTED_MODULE_1__);



const MultiSelectLabelInput = ({ tags , selectedValue , onSelect , onRemove , name  })=>{
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_MultiSelectLabelInput_module_scss__WEBPACK_IMPORTED_MODULE_2___default()["input-label-section"]),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                className: (_MultiSelectLabelInput_module_scss__WEBPACK_IMPORTED_MODULE_2___default()["section-input-label"]),
                children: name
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((multiselect_react_dropdown__WEBPACK_IMPORTED_MODULE_1___default()), {
                options: tags.map((tag)=>({
                        name: tag.name,
                        id: tag.id
                    })
                ),
                selectedValues: selectedValue,
                onSelect: onSelect,
                onRemove: onRemove,
                displayValue: "name",
                className: (_MultiSelectLabelInput_module_scss__WEBPACK_IMPORTED_MODULE_2___default()["section-input-value"])
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MultiSelectLabelInput);


/***/ })

};
;