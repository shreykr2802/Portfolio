exports.id = 904;
exports.ids = [904];
exports.modules = {

/***/ 7298:
/***/ ((module) => {

// Exports
module.exports = {
	"loading-container": "Loading_loading-container__sj6uA",
	"loading-heart": "Loading_loading-heart__EExz4",
	"lds-heart": "Loading_lds-heart__5m0ZW"
};


/***/ }),

/***/ 7427:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _Loading_module_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7298);
/* harmony import */ var _Loading_module_scss__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_Loading_module_scss__WEBPACK_IMPORTED_MODULE_1__);


const Loading = ()=>{
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: (_Loading_module_scss__WEBPACK_IMPORTED_MODULE_1___default()["loading-container"]),
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: (_Loading_module_scss__WEBPACK_IMPORTED_MODULE_1___default()["loading-heart"]),
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {})
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Loading);


/***/ }),

/***/ 9932:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "o": () => (/* binding */ formatDateTime)
});

// EXTERNAL MODULE: external "moment"
var external_moment_ = __webpack_require__(2245);
var external_moment_default = /*#__PURE__*/__webpack_require__.n(external_moment_);
;// CONCATENATED MODULE: ./utils/constants.ts
const DATE_FORMAT = "YYYY-MM-DDThh:mm:ss.msZ";

;// CONCATENATED MODULE: ./utils/dateTimeUtil.ts


const formatDateTime = (date)=>{
    const convertedDate = external_moment_default()(date, DATE_FORMAT, false);
    return convertedDate.fromNow();
};


/***/ }),

/***/ 7835:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_0__);

const useSelector = (0,react_redux__WEBPACK_IMPORTED_MODULE_0__.createSelectorHook)();
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useSelector);


/***/ })

};
;