"use strict";
(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 9951:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _app)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(6022);
;// CONCATENATED MODULE: external "redux"
const external_redux_namespaceObject = require("redux");
;// CONCATENATED MODULE: external "redux-thunk"
const external_redux_thunk_namespaceObject = require("redux-thunk");
var external_redux_thunk_default = /*#__PURE__*/__webpack_require__.n(external_redux_thunk_namespaceObject);
;// CONCATENATED MODULE: external "redux-saga"
const external_redux_saga_namespaceObject = require("redux-saga");
var external_redux_saga_default = /*#__PURE__*/__webpack_require__.n(external_redux_saga_namespaceObject);
// EXTERNAL MODULE: ./redux/slices/blogSlice.ts
var blogSlice = __webpack_require__(9833);
// EXTERNAL MODULE: ./redux/slices/tagSlice.ts
var tagSlice = __webpack_require__(3256);
// EXTERNAL MODULE: ./redux/slices/contentSlice.ts
var contentSlice = __webpack_require__(9976);
// EXTERNAL MODULE: ./redux/slices/appSlice.ts
var appSlice = __webpack_require__(5031);
;// CONCATENATED MODULE: external "redux-saga/effects"
const effects_namespaceObject = require("redux-saga/effects");
;// CONCATENATED MODULE: external "axios"
const external_axios_namespaceObject = require("axios");
var external_axios_default = /*#__PURE__*/__webpack_require__.n(external_axios_namespaceObject);
;// CONCATENATED MODULE: ./redux/axios/axios.ts

const instance = external_axios_default().create({
    baseURL: "https://api.shreykumar.com/api"
});
instance.interceptors.request.use((config)=>{
    if (config.url?.includes("/admin/") || config.url?.includes("/attachment")) {
        config.headers = {
            ...config.headers,
            'x-auth-token': localStorage.getItem("accessToken") || ""
        };
        return config;
    } else {
        return config;
    }
});
/* harmony default export */ const axios = (instance);

// EXTERNAL MODULE: ./redux/slices/adminSlice.ts
var adminSlice = __webpack_require__(6968);
;// CONCATENATED MODULE: ./redux/sagas/adminSaga.ts



function* adminNewTagSaga(action) {
    try {
        const response = yield axios.post(`/admin/create-new-tag`, {
            "name": action.payload.name,
            "data": action.payload.base64,
            "priority": 1,
            "type": "tags"
        });
        yield (0,effects_namespaceObject.put)((0,adminSlice/* insertNewTagSuccess */.gU)(response.data));
    } catch (error) {
        yield (0,effects_namespaceObject.put)((0,adminSlice/* insertNewTagFailed */.V5)(error));
    }
}
function* adminNewBlogSaga(action) {
    try {
        const response = yield axios.post(`/admin/create-new-blog`, action.payload);
        yield (0,effects_namespaceObject.put)((0,adminSlice/* insertNewBlogSuccess */.xp)(response.data));
    } catch (error) {
        yield (0,effects_namespaceObject.put)((0,adminSlice/* insertNewTagFailed */.V5)(error));
    }
}
function* updateBlogSaga(action) {
    try {
        const response = yield axios.post(`/admin/update-a-blog`, action.payload);
        yield (0,effects_namespaceObject.put)((0,adminSlice/* updateBlogSuccess */.af)(response.data));
    } catch (error) {
        yield (0,effects_namespaceObject.put)((0,adminSlice/* updateBlogFailed */.O_)(error));
    }
}
function* adminUpdateTagSaga(action) {
    try {
        const response = yield axios.post(`/admin/update-a-tag`, {
            "id": action.payload.id,
            "name": action.payload.name,
            "data": action.payload.base64,
            "priority": 1,
            "type": "tags",
            "isAttachment": action.payload.isAttachment
        });
        yield (0,effects_namespaceObject.put)((0,adminSlice/* updateATagSuccess */._R)(response.data));
    } catch (error) {
        yield (0,effects_namespaceObject.put)((0,adminSlice/* updateATagFailed */.jL)(error));
    }
}
function* adminClearResultSaga() {
    try {
        yield (0,effects_namespaceObject.put)((0,adminSlice/* clearResultSuccess */.o9)());
    } catch (err) {
        yield (0,effects_namespaceObject.put)((0,adminSlice/* clearResultFailed */.IL)("error while clearing results"));
    }
}
function* watchAdmin() {
    yield (0,effects_namespaceObject.takeLatest)(adminSlice/* insertNewTagStart */.X0, adminNewTagSaga);
    yield (0,effects_namespaceObject.takeLatest)(adminSlice/* insertNewBlogStart */.Pl, adminNewBlogSaga);
    yield (0,effects_namespaceObject.takeLatest)(adminSlice/* updateBlogStart */.hq, updateBlogSaga);
    yield (0,effects_namespaceObject.takeLatest)(adminSlice/* updateATagStart */.ox, adminUpdateTagSaga);
    yield (0,effects_namespaceObject.takeLatest)(adminSlice/* clearResultStart */.uv, adminClearResultSaga);
}
/* harmony default export */ const adminSaga = (watchAdmin);

// EXTERNAL MODULE: ./redux/slices/authSlice.ts
var authSlice = __webpack_require__(1781);
;// CONCATENATED MODULE: ./redux/sagas/authSaga.ts



function* authSaga(action) {
    try {
        const response = yield axios.post(`/auth`, {
            "username": action.payload.username,
            "password": action.payload.password
        });
        yield (0,effects_namespaceObject.put)((0,authSlice/* fetchAuthSuccess */.gt)(response.data.token));
        yield localStorage.setItem("accessToken", response.data.token);
    } catch (error) {
        yield (0,effects_namespaceObject.put)((0,authSlice/* fetchAuthFailed */.VC)(error));
    }
}
function* watchAuth() {
    yield (0,effects_namespaceObject.takeLatest)(authSlice/* fetchAuthStart */.ME, authSaga);
}
/* harmony default export */ const sagas_authSaga = (watchAuth);

;// CONCATENATED MODULE: ./redux/sagas/blogSaga.ts



function* blogSaga() {
    try {
        const response = yield axios.get("/blogs");
        yield (0,effects_namespaceObject.put)((0,blogSlice/* fetchBlogDataSuccess */.Tz)(response.data));
    } catch (error) {
        yield (0,effects_namespaceObject.put)((0,blogSlice/* fetchBlogDataFailed */.b8)(error));
    }
}
function* searchBlogByIdSaga(action) {
    try {
        const response = yield axios.get(`/blogs/${action.payload}`);
        const responseContent = yield axios.get(`/blogs-data/${action.payload}`);
        yield (0,effects_namespaceObject.put)((0,blogSlice/* fetchBlogDataByIdSuccess */.MO)({
            ...response.data,
            content: responseContent.data.content
        }));
    } catch (error) {
        yield (0,effects_namespaceObject.put)((0,blogSlice/* fetchBlogDataByIdFailed */.Mi)(error));
    }
}
function* watchBlogData() {
    yield (0,effects_namespaceObject.takeLatest)(blogSlice/* fetchBlogDataStart */.a, blogSaga);
    yield (0,effects_namespaceObject.takeLatest)(blogSlice/* fetchBlogDataByIdStart */.I2, searchBlogByIdSaga);
}
/* harmony default export */ const sagas_blogSaga = (watchBlogData);

;// CONCATENATED MODULE: ./redux/sagas/contentSaga.ts



function* contentSaga(action) {
    try {
        const response = yield axios.get(`/blogs-data/${action.payload}`);
        yield (0,effects_namespaceObject.put)((0,contentSlice/* fetchContentDataSuccess */.uN)(response.data));
    } catch (error) {
        yield (0,effects_namespaceObject.put)((0,contentSlice/* fetchContentDataFailed */.iY)(error));
    }
}
function* watchContentData() {
    yield (0,effects_namespaceObject.takeLatest)(contentSlice/* fetchContentDataStart */.$D, contentSaga);
}
/* harmony default export */ const sagas_contentSaga = (watchContentData);

;// CONCATENATED MODULE: ./redux/sagas/tagSaga.ts



function* tagSaga() {
    try {
        const response = yield axios.get("/tags");
        yield (0,effects_namespaceObject.put)((0,tagSlice/* fetchTagDataSuccess */.bM)(response.data));
    } catch (error) {
        yield (0,effects_namespaceObject.put)((0,tagSlice/* fetchTagDataFailed */.b1)(error));
    }
}
function* plainTagSaga() {
    try {
        const response = yield axios.get("/tags/no-image");
        yield (0,effects_namespaceObject.put)((0,tagSlice/* fetchPlainTagDataSuccess */.yq)(response.data));
    } catch (error) {
        yield (0,effects_namespaceObject.put)((0,tagSlice/* fetchPlainTagDataFailed */.rW)(error));
    }
}
function* watchTagData() {
    yield (0,effects_namespaceObject.takeLatest)(tagSlice/* fetchTagDataStart */.zd, tagSaga);
    yield (0,effects_namespaceObject.takeLatest)(tagSlice/* fetchPlainTagDataStart */.Ls, plainTagSaga);
}
/* harmony default export */ const sagas_tagSaga = (watchTagData);

;// CONCATENATED MODULE: ./redux/sagas/index.ts






function* rootSaga() {
    yield (0,effects_namespaceObject.all)([
        sagas_blogSaga(),
        sagas_tagSaga(),
        sagas_contentSaga(),
        sagas_authSaga(),
        adminSaga()
    ]);
}
/* harmony default export */ const sagas = (rootSaga);

;// CONCATENATED MODULE: ./redux/store/index.ts










const rootReducer = (0,external_redux_namespaceObject.combineReducers)({
    app: appSlice/* default */.Z,
    blogs: blogSlice/* default */.ZP,
    tags: tagSlice/* default */.ZP,
    content: contentSlice/* default */.ZP,
    auth: authSlice/* default */.ZP,
    admin: adminSlice/* default */.ZP
});
//@ts-ignore
const composeEnhancers =  false || external_redux_namespaceObject.compose;
const sagaMiddleware = external_redux_saga_default()();
const store = (0,external_redux_namespaceObject.createStore)(rootReducer, composeEnhancers((0,external_redux_namespaceObject.applyMiddleware)((external_redux_thunk_default()), sagaMiddleware)));
sagaMiddleware.run(sagas);
/* harmony default export */ const redux_store = (store);

;// CONCATENATED MODULE: ./pages/_app.tsx




function MyApp({ Component , pageProps  }) {
    return(/*#__PURE__*/ jsx_runtime_.jsx(external_react_redux_.Provider, {
        store: redux_store,
        children: /*#__PURE__*/ jsx_runtime_.jsx(Component, {
            ...pageProps
        })
    }));
}
/* harmony default export */ const _app = (MyApp);


/***/ }),

/***/ 5031:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "A": () => (/* binding */ setShowContactForm),
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const initialState = {
    showContactForm: false
};
const appSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "app",
    initialState,
    reducers: {
        setShowContactForm: (state)=>{
            state.showContactForm = !state.showContactForm;
        }
    }
});
const { setShowContactForm  } = appSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (appSlice.reducer);


/***/ }),

/***/ 1781:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ME": () => (/* binding */ fetchAuthStart),
/* harmony export */   "gt": () => (/* binding */ fetchAuthSuccess),
/* harmony export */   "VC": () => (/* binding */ fetchAuthFailed),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const initialState = {
    token: "",
    error: "",
    loading: false
};
const authSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "authData",
    initialState,
    reducers: {
        fetchAuthStart: (state, action)=>{
            state.error = "";
            state.loading = true;
        },
        fetchAuthSuccess: (state, action)=>{
            state.error = "";
            state.loading = false;
            state.token = action.payload;
        },
        fetchAuthFailed: (state, action)=>{
            state.error = action.payload;
            state.loading = false;
        }
    }
});
const { fetchAuthStart , fetchAuthSuccess , fetchAuthFailed  } = authSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (authSlice.reducer);


/***/ }),

/***/ 9976:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$D": () => (/* binding */ fetchContentDataStart),
/* harmony export */   "uN": () => (/* binding */ fetchContentDataSuccess),
/* harmony export */   "iY": () => (/* binding */ fetchContentDataFailed),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const initialState = {
    content: {},
    error: "",
    loading: false,
    activeId: "0"
};
const contentSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "contentData",
    initialState,
    reducers: {
        fetchContentDataStart: (state, action)=>{
            state.error = "";
            state.loading = true;
            state.activeId = action.payload;
        },
        fetchContentDataSuccess: (state, action)=>{
            state.error = "";
            state.loading = false;
            state.content = action.payload;
        },
        fetchContentDataFailed: (state, action)=>{
            state.error = action.payload;
            state.loading = false;
        }
    }
});
const { fetchContentDataStart , fetchContentDataSuccess , fetchContentDataFailed  } = contentSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (contentSlice.reducer);


/***/ }),

/***/ 5184:
/***/ ((module) => {

module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 6022:
/***/ ((module) => {

module.exports = require("react-redux");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [968,256,833], () => (__webpack_exec__(9951)));
module.exports = __webpack_exports__;

})();